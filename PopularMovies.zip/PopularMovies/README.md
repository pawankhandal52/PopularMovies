# PopularMovies
This is simple app which show the popular movies from TMDB.

To Run this app first you need to clone it and just add your api keys which can you get from here https://www.themoviedb.org/account/signup

### Step to add your API Key.
1.Just open gradle.properties file from gradle folder.

2.You see there is a line Movies_ApiKey="YOUR_API_KEY_IS_HERE"

3.Just Replace your key with this "YOUR_API_KEY_IS_HERE"

4. ThenBuild your Project

5. Run this and you can see popular movies.

### Screenshot of app
![device-2018-08-04-112829](https://user-images.githubusercontent.com/16113573/43673102-4cb94a8a-97da-11e8-999f-74c0defb79da.png)
![device-2018-08-04-112906](https://user-images.githubusercontent.com/16113573/43673103-4ce6409e-97da-11e8-9030-66a0723fac3d.png)
![device-2018-08-04-112953](https://user-images.githubusercontent.com/16113573/43673104-4d117c8c-97da-11e8-8f65-1f882b67fabb.png)
![device-2018-08-04-113038](https://user-images.githubusercontent.com/16113573/43673105-4d3ec002-97da-11e8-98fa-3147998d0bd0.png)
